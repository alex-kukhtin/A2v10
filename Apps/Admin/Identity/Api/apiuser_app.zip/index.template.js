﻿
/* identity/user index template */

const template = {
	properties: {
	},
	events: {
	},
	validators: {
	},
	commands: {
	}
};

module.exports = template;
